export { AstroCheck, CheckResult, Diagnostic, DiagnosticSeverity } from './check.js';
