/// <reference types="astro/client" />


declare module 'im-a-super-module' {
	export const hello: string;
}
