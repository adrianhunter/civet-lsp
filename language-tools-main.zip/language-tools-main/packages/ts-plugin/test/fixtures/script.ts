export function sayHello() {
	console.log("Hello")
}

MyAstroCompon

export class Hello {

}

import { } from './MyAstroComponent.astro'
